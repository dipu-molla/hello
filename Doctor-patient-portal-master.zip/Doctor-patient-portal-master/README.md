# Doctor-patient-portal
Doctors appointment system using C#
# Tools
    Microsoft Visual Studio 
    Microsoft Sql Server Management Studio
