﻿namespace Doctors_Patients_portal
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.confirmationlabel = new System.Windows.Forms.Label();
            this.reginame = new System.Windows.Forms.Label();
            this.regiaddress = new System.Windows.Forms.Label();
            this.regiusername = new System.Windows.Forms.Label();
            this.regipass = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.regiconpass = new System.Windows.Forms.Label();
            this.reginametext = new System.Windows.Forms.TextBox();
            this.regiaddresstext = new System.Windows.Forms.TextBox();
            this.regiusertext = new System.Windows.Forms.TextBox();
            this.regipasstext = new System.Windows.Forms.TextBox();
            this.regiconpasstext = new System.Windows.Forms.TextBox();
            this.specialistlbl = new System.Windows.Forms.Label();
            this.hos1lbl = new System.Windows.Forms.Label();
            this.hos1 = new System.Windows.Forms.Label();
            this.hos2 = new System.Windows.Forms.Label();
            this.createbtn = new System.Windows.Forms.Button();
            this.radioButtondoc = new System.Windows.Forms.RadioButton();
            this.radioButtonpatient = new System.Windows.Forms.RadioButton();
            this.nameinvalid = new System.Windows.Forms.Label();
            this.addinvalid = new System.Windows.Forms.Label();
            this.usernameinvalid = new System.Windows.Forms.Label();
            this.passinvalid = new System.Windows.Forms.Label();
            this.cpassinvalid = new System.Windows.Forms.Label();
            this.specialinvalid = new System.Windows.Forms.Label();
            this.specialtxt = new System.Windows.Forms.ComboBox();
            this.hos1combo = new System.Windows.Forms.ComboBox();
            this.hos2combo = new System.Windows.Forms.ComboBox();
            this.hos1slot = new System.Windows.Forms.ComboBox();
            this.hos2slot = new System.Windows.Forms.ComboBox();
            this.hos1slotlbl = new System.Windows.Forms.Label();
            this.hos2slotlbl = new System.Windows.Forms.Label();
            this.adminradiobtn = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // confirmationlabel
            // 
            this.confirmationlabel.AutoSize = true;
            this.confirmationlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmationlabel.Location = new System.Drawing.Point(190, 17);
            this.confirmationlabel.Name = "confirmationlabel";
            this.confirmationlabel.Size = new System.Drawing.Size(75, 24);
            this.confirmationlabel.TabIndex = 0;
            this.confirmationlabel.Text = "I am a...";
            // 
            // reginame
            // 
            this.reginame.AutoSize = true;
            this.reginame.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reginame.Location = new System.Drawing.Point(190, 64);
            this.reginame.Name = "reginame";
            this.reginame.Size = new System.Drawing.Size(61, 24);
            this.reginame.TabIndex = 3;
            this.reginame.Text = "Name";
            // 
            // regiaddress
            // 
            this.regiaddress.AutoSize = true;
            this.regiaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiaddress.Location = new System.Drawing.Point(171, 98);
            this.regiaddress.Name = "regiaddress";
            this.regiaddress.Size = new System.Drawing.Size(80, 24);
            this.regiaddress.TabIndex = 4;
            this.regiaddress.Text = "Address";
            // 
            // regiusername
            // 
            this.regiusername.AutoSize = true;
            this.regiusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiusername.Location = new System.Drawing.Point(146, 135);
            this.regiusername.Name = "regiusername";
            this.regiusername.Size = new System.Drawing.Size(105, 24);
            this.regiusername.TabIndex = 5;
            this.regiusername.Text = "User Name";
            // 
            // regipass
            // 
            this.regipass.AutoSize = true;
            this.regipass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regipass.Location = new System.Drawing.Point(159, 170);
            this.regipass.Name = "regipass";
            this.regipass.Size = new System.Drawing.Size(92, 24);
            this.regipass.TabIndex = 6;
            this.regipass.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 210);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 24);
            this.label1.TabIndex = 7;
            // 
            // regiconpass
            // 
            this.regiconpass.AutoSize = true;
            this.regiconpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiconpass.Location = new System.Drawing.Point(89, 205);
            this.regiconpass.Name = "regiconpass";
            this.regiconpass.Size = new System.Drawing.Size(162, 24);
            this.regiconpass.TabIndex = 8;
            this.regiconpass.Text = "Confirm Password";
            // 
            // reginametext
            // 
            this.reginametext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reginametext.Location = new System.Drawing.Point(257, 63);
            this.reginametext.Name = "reginametext";
            this.reginametext.Size = new System.Drawing.Size(380, 29);
            this.reginametext.TabIndex = 9;
            this.reginametext.TextChanged += new System.EventHandler(this.reginametext_TextChanged);
            // 
            // regiaddresstext
            // 
            this.regiaddresstext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiaddresstext.Location = new System.Drawing.Point(257, 98);
            this.regiaddresstext.Name = "regiaddresstext";
            this.regiaddresstext.Size = new System.Drawing.Size(380, 29);
            this.regiaddresstext.TabIndex = 10;
            this.regiaddresstext.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // regiusertext
            // 
            this.regiusertext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiusertext.Location = new System.Drawing.Point(257, 135);
            this.regiusertext.Name = "regiusertext";
            this.regiusertext.Size = new System.Drawing.Size(380, 29);
            this.regiusertext.TabIndex = 11;
            this.regiusertext.TextChanged += new System.EventHandler(this.regiusertext_TextChanged);
            // 
            // regipasstext
            // 
            this.regipasstext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regipasstext.Location = new System.Drawing.Point(257, 170);
            this.regipasstext.Name = "regipasstext";
            this.regipasstext.Size = new System.Drawing.Size(380, 29);
            this.regipasstext.TabIndex = 12;
            this.regipasstext.UseSystemPasswordChar = true;
            this.regipasstext.TextChanged += new System.EventHandler(this.regipasstext_TextChanged);
            // 
            // regiconpasstext
            // 
            this.regiconpasstext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiconpasstext.Location = new System.Drawing.Point(257, 205);
            this.regiconpasstext.Name = "regiconpasstext";
            this.regiconpasstext.Size = new System.Drawing.Size(380, 29);
            this.regiconpasstext.TabIndex = 13;
            this.regiconpasstext.UseSystemPasswordChar = true;
            this.regiconpasstext.TextChanged += new System.EventHandler(this.regiconpasstext_TextChanged);
            // 
            // specialistlbl
            // 
            this.specialistlbl.AutoSize = true;
            this.specialistlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.specialistlbl.Location = new System.Drawing.Point(162, 243);
            this.specialistlbl.Name = "specialistlbl";
            this.specialistlbl.Size = new System.Drawing.Size(89, 24);
            this.specialistlbl.TabIndex = 14;
            this.specialistlbl.Text = "Specialist";
            // 
            // hos1lbl
            // 
            this.hos1lbl.AutoSize = true;
            this.hos1lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos1lbl.Location = new System.Drawing.Point(162, 284);
            this.hos1lbl.Name = "hos1lbl";
            this.hos1lbl.Size = new System.Drawing.Size(197, 24);
            this.hos1lbl.TabIndex = 15;
            this.hos1lbl.Text = "Hospitals you work in..";
            // 
            // hos1
            // 
            this.hos1.AutoSize = true;
            this.hos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos1.Location = new System.Drawing.Point(231, 314);
            this.hos1.Name = "hos1";
            this.hos1.Size = new System.Drawing.Size(20, 24);
            this.hos1.TabIndex = 16;
            this.hos1.Text = "1";
            // 
            // hos2
            // 
            this.hos2.AutoSize = true;
            this.hos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos2.Location = new System.Drawing.Point(231, 409);
            this.hos2.Name = "hos2";
            this.hos2.Size = new System.Drawing.Size(20, 24);
            this.hos2.TabIndex = 17;
            this.hos2.Text = "2";
            // 
            // createbtn
            // 
            this.createbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.createbtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createbtn.Location = new System.Drawing.Point(257, 485);
            this.createbtn.Name = "createbtn";
            this.createbtn.Size = new System.Drawing.Size(380, 38);
            this.createbtn.TabIndex = 21;
            this.createbtn.Text = "Create Account";
            this.createbtn.UseVisualStyleBackColor = false;
            this.createbtn.Click += new System.EventHandler(this.createbtn_Click);
            // 
            // radioButtondoc
            // 
            this.radioButtondoc.AutoSize = true;
            this.radioButtondoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtondoc.Location = new System.Drawing.Point(276, 15);
            this.radioButtondoc.Name = "radioButtondoc";
            this.radioButtondoc.Size = new System.Drawing.Size(83, 28);
            this.radioButtondoc.TabIndex = 22;
            this.radioButtondoc.TabStop = true;
            this.radioButtondoc.Text = "Doctor";
            this.radioButtondoc.UseVisualStyleBackColor = true;
            this.radioButtondoc.CheckedChanged += new System.EventHandler(this.radioButtondoc_CheckedChanged);
            // 
            // radioButtonpatient
            // 
            this.radioButtonpatient.AutoSize = true;
            this.radioButtonpatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonpatient.Location = new System.Drawing.Point(365, 15);
            this.radioButtonpatient.Name = "radioButtonpatient";
            this.radioButtonpatient.Size = new System.Drawing.Size(84, 28);
            this.radioButtonpatient.TabIndex = 23;
            this.radioButtonpatient.TabStop = true;
            this.radioButtonpatient.Text = "Patient";
            this.radioButtonpatient.UseVisualStyleBackColor = true;
            this.radioButtonpatient.CheckedChanged += new System.EventHandler(this.radioButtonpatient_CheckedChanged);
            // 
            // nameinvalid
            // 
            this.nameinvalid.AutoSize = true;
            this.nameinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameinvalid.ForeColor = System.Drawing.Color.Red;
            this.nameinvalid.Location = new System.Drawing.Point(643, 66);
            this.nameinvalid.Name = "nameinvalid";
            this.nameinvalid.Size = new System.Drawing.Size(96, 24);
            this.nameinvalid.TabIndex = 24;
            this.nameinvalid.Text = "INVALID!!!";
            this.nameinvalid.Visible = false;
            // 
            // addinvalid
            // 
            this.addinvalid.AutoSize = true;
            this.addinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addinvalid.ForeColor = System.Drawing.Color.Red;
            this.addinvalid.Location = new System.Drawing.Point(643, 101);
            this.addinvalid.Name = "addinvalid";
            this.addinvalid.Size = new System.Drawing.Size(96, 24);
            this.addinvalid.TabIndex = 25;
            this.addinvalid.Text = "INVALID!!!";
            this.addinvalid.Visible = false;
            // 
            // usernameinvalid
            // 
            this.usernameinvalid.AutoSize = true;
            this.usernameinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameinvalid.ForeColor = System.Drawing.Color.Red;
            this.usernameinvalid.Location = new System.Drawing.Point(643, 138);
            this.usernameinvalid.Name = "usernameinvalid";
            this.usernameinvalid.Size = new System.Drawing.Size(96, 24);
            this.usernameinvalid.TabIndex = 26;
            this.usernameinvalid.Text = "INVALID!!!";
            this.usernameinvalid.Visible = false;
            // 
            // passinvalid
            // 
            this.passinvalid.AutoSize = true;
            this.passinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passinvalid.ForeColor = System.Drawing.Color.Red;
            this.passinvalid.Location = new System.Drawing.Point(643, 173);
            this.passinvalid.Name = "passinvalid";
            this.passinvalid.Size = new System.Drawing.Size(96, 24);
            this.passinvalid.TabIndex = 27;
            this.passinvalid.Text = "INVALID!!!";
            this.passinvalid.Visible = false;
            // 
            // cpassinvalid
            // 
            this.cpassinvalid.AutoSize = true;
            this.cpassinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpassinvalid.ForeColor = System.Drawing.Color.Red;
            this.cpassinvalid.Location = new System.Drawing.Point(643, 208);
            this.cpassinvalid.Name = "cpassinvalid";
            this.cpassinvalid.Size = new System.Drawing.Size(96, 24);
            this.cpassinvalid.TabIndex = 28;
            this.cpassinvalid.Text = "INVALID!!!";
            this.cpassinvalid.Visible = false;
            // 
            // specialinvalid
            // 
            this.specialinvalid.AutoSize = true;
            this.specialinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.specialinvalid.ForeColor = System.Drawing.Color.Red;
            this.specialinvalid.Location = new System.Drawing.Point(643, 246);
            this.specialinvalid.Name = "specialinvalid";
            this.specialinvalid.Size = new System.Drawing.Size(96, 24);
            this.specialinvalid.TabIndex = 29;
            this.specialinvalid.Text = "INVALID!!!";
            this.specialinvalid.Visible = false;
            // 
            // specialtxt
            // 
            this.specialtxt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.specialtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.specialtxt.FormattingEnabled = true;
            this.specialtxt.Items.AddRange(new object[] {
            "CARDIAC AND VASCULAR SURGERY",
            "CHILD DEVELOPEMENT",
            "MEDICINE",
            "DENTAL",
            "DERMATOLOGY"});
            this.specialtxt.Location = new System.Drawing.Point(257, 240);
            this.specialtxt.Name = "specialtxt";
            this.specialtxt.Size = new System.Drawing.Size(380, 32);
            this.specialtxt.TabIndex = 30;
            this.specialtxt.SelectedIndexChanged += new System.EventHandler(this.specialtxt_SelectedIndexChanged);
            // 
            // hos1combo
            // 
            this.hos1combo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hos1combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos1combo.FormattingEnabled = true;
            this.hos1combo.Items.AddRange(new object[] {
            "Appollo Hospital",
            "Square Hospital",
            "United Hospital",
            "Dhaka Medical"});
            this.hos1combo.Location = new System.Drawing.Point(257, 311);
            this.hos1combo.Name = "hos1combo";
            this.hos1combo.Size = new System.Drawing.Size(380, 32);
            this.hos1combo.TabIndex = 31;
            this.hos1combo.SelectedIndexChanged += new System.EventHandler(this.hos1combo_SelectedIndexChanged);
            // 
            // hos2combo
            // 
            this.hos2combo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hos2combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos2combo.FormattingEnabled = true;
            this.hos2combo.Items.AddRange(new object[] {
            "Appollo Hospital",
            "Square Hospital",
            "United Hospital",
            "Dhaka Medical"});
            this.hos2combo.Location = new System.Drawing.Point(257, 409);
            this.hos2combo.Name = "hos2combo";
            this.hos2combo.Size = new System.Drawing.Size(380, 32);
            this.hos2combo.TabIndex = 32;
            this.hos2combo.SelectedIndexChanged += new System.EventHandler(this.hos2combo_SelectedIndexChanged);
            // 
            // hos1slot
            // 
            this.hos1slot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hos1slot.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos1slot.FormattingEnabled = true;
            this.hos1slot.Items.AddRange(new object[] {
            "10 AM - 2 PM",
            "12 PM - 4 PM",
            "6 PM - 9 PM",
            "7 PM - 10 PM "});
            this.hos1slot.Location = new System.Drawing.Point(257, 349);
            this.hos1slot.Name = "hos1slot";
            this.hos1slot.Size = new System.Drawing.Size(380, 32);
            this.hos1slot.TabIndex = 33;
            this.hos1slot.SelectedIndexChanged += new System.EventHandler(this.hos1slot_SelectedIndexChanged);
            // 
            // hos2slot
            // 
            this.hos2slot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hos2slot.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos2slot.FormattingEnabled = true;
            this.hos2slot.Items.AddRange(new object[] {
            "10 AM - 2 PM",
            "12 PM - 4 PM",
            "6 PM - 9 PM",
            "7 PM - 10 PM "});
            this.hos2slot.Location = new System.Drawing.Point(257, 447);
            this.hos2slot.Name = "hos2slot";
            this.hos2slot.Size = new System.Drawing.Size(380, 32);
            this.hos2slot.TabIndex = 34;
            this.hos2slot.SelectedIndexChanged += new System.EventHandler(this.hos2slot_SelectedIndexChanged);
            // 
            // hos1slotlbl
            // 
            this.hos1slotlbl.AutoSize = true;
            this.hos1slotlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos1slotlbl.Location = new System.Drawing.Point(162, 352);
            this.hos1slotlbl.Name = "hos1slotlbl";
            this.hos1slotlbl.Size = new System.Drawing.Size(89, 24);
            this.hos1slotlbl.TabIndex = 35;
            this.hos1slotlbl.Text = "Time Slot";
            // 
            // hos2slotlbl
            // 
            this.hos2slotlbl.AutoSize = true;
            this.hos2slotlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hos2slotlbl.Location = new System.Drawing.Point(162, 450);
            this.hos2slotlbl.Name = "hos2slotlbl";
            this.hos2slotlbl.Size = new System.Drawing.Size(89, 24);
            this.hos2slotlbl.TabIndex = 36;
            this.hos2slotlbl.Text = "Time Slot";
            // 
            // adminradiobtn
            // 
            this.adminradiobtn.AutoSize = true;
            this.adminradiobtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminradiobtn.Location = new System.Drawing.Point(455, 17);
            this.adminradiobtn.Name = "adminradiobtn";
            this.adminradiobtn.Size = new System.Drawing.Size(83, 28);
            this.adminradiobtn.TabIndex = 37;
            this.adminradiobtn.TabStop = true;
            this.adminradiobtn.Text = "Admin";
            this.adminradiobtn.UseVisualStyleBackColor = true;
            this.adminradiobtn.CheckedChanged += new System.EventHandler(this.adminradiobtn_CheckedChanged);
            // 
            // signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(50, 50);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(939, 500);
            this.Controls.Add(this.adminradiobtn);
            this.Controls.Add(this.hos2slotlbl);
            this.Controls.Add(this.hos1slotlbl);
            this.Controls.Add(this.hos2slot);
            this.Controls.Add(this.hos1slot);
            this.Controls.Add(this.hos2combo);
            this.Controls.Add(this.hos1combo);
            this.Controls.Add(this.specialtxt);
            this.Controls.Add(this.specialinvalid);
            this.Controls.Add(this.cpassinvalid);
            this.Controls.Add(this.passinvalid);
            this.Controls.Add(this.usernameinvalid);
            this.Controls.Add(this.addinvalid);
            this.Controls.Add(this.nameinvalid);
            this.Controls.Add(this.radioButtonpatient);
            this.Controls.Add(this.radioButtondoc);
            this.Controls.Add(this.createbtn);
            this.Controls.Add(this.hos2);
            this.Controls.Add(this.hos1);
            this.Controls.Add(this.hos1lbl);
            this.Controls.Add(this.specialistlbl);
            this.Controls.Add(this.regiconpasstext);
            this.Controls.Add(this.regipasstext);
            this.Controls.Add(this.regiusertext);
            this.Controls.Add(this.regiaddresstext);
            this.Controls.Add(this.reginametext);
            this.Controls.Add(this.regiconpass);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.regipass);
            this.Controls.Add(this.regiusername);
            this.Controls.Add(this.regiaddress);
            this.Controls.Add(this.reginame);
            this.Controls.Add(this.confirmationlabel);
            this.Name = "signup";
            this.Text = "Create Account";
            this.Load += new System.EventHandler(this.signup_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label confirmationlabel;
        private System.Windows.Forms.Label reginame;
        private System.Windows.Forms.Label regiaddress;
        private System.Windows.Forms.Label regiusername;
        private System.Windows.Forms.Label regipass;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label regiconpass;
        private System.Windows.Forms.TextBox reginametext;
        private System.Windows.Forms.TextBox regiaddresstext;
        private System.Windows.Forms.TextBox regiusertext;
        private System.Windows.Forms.TextBox regipasstext;
        private System.Windows.Forms.TextBox regiconpasstext;
        private System.Windows.Forms.Label specialistlbl;
        private System.Windows.Forms.Label hos1lbl;
        private System.Windows.Forms.Label hos1;
        private System.Windows.Forms.Label hos2;
        private System.Windows.Forms.Button createbtn;
        private System.Windows.Forms.RadioButton radioButtondoc;
        private System.Windows.Forms.RadioButton radioButtonpatient;
        private System.Windows.Forms.Label nameinvalid;
        private System.Windows.Forms.Label addinvalid;
        private System.Windows.Forms.Label usernameinvalid;
        private System.Windows.Forms.Label passinvalid;
        private System.Windows.Forms.Label cpassinvalid;
        private System.Windows.Forms.Label specialinvalid;
        private System.Windows.Forms.ComboBox specialtxt;
        private System.Windows.Forms.ComboBox hos1combo;
        private System.Windows.Forms.ComboBox hos2combo;
        private System.Windows.Forms.ComboBox hos1slot;
        private System.Windows.Forms.ComboBox hos2slot;
        private System.Windows.Forms.Label hos1slotlbl;
        private System.Windows.Forms.Label hos2slotlbl;
        private System.Windows.Forms.RadioButton adminradiobtn;
    }
}